'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card'
import { useToast } from '@/components/ui/use-toast'
import Logo from '@/components/Logo'

export default function Signup() {
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const router = useRouter()
  const { toast } = useToast()

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    console.log('Signup attempt with:', name, email, password)
    localStorage.setItem('authToken', 'demo-token')
    toast({
      title: "Account Created",
      description: "Welcome to Felo! Your account has been successfully created.",
    })
    router.push('/dashboard')
  }

  return (
    <div className="flex items-center justify-center min-h-[calc(100vh-64px)] bg-gray-100">
      <Card className="w-[400px] shadow-xl">
        <CardHeader className="bg-blue-600 text-white">
          <div className="flex items-center space-x-2 mb-4">
            <Logo className="text-white" />
            <CardTitle className="text-2xl font-bold">Sign Up for Felo</CardTitle>
          </div>
          <CardDescription className="text-blue-100">Create your account to get started</CardDescription>
        </CardHeader>
        <CardContent className="pt-6">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name" className="text-sm font-medium text-gray-700">Name</Label>
              <Input 
                id="name" 
                type="text" 
                placeholder="Your name" 
                value={name} 
                onChange={(e) => setName(e.target.value)}
                className="w-full p-2 text-base border border-gray-300 rounded-md focus:border-blue-500 focus:ring focus:ring-blue-200"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="email" className="text-sm font-medium text-gray-700">Email</Label>
              <Input 
                id="email" 
                type="email" 
                placeholder="Your email" 
                value={email} 
                onChange={(e) => setEmail(e.target.value)}
                className="w-full p-2 text-base border border-gray-300 rounded-md focus:border-blue-500 focus:ring focus:ring-blue-200"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password" className="text-sm font-medium text-gray-700">Password</Label>
              <Input 
                id="password" 
                type="password" 
                placeholder="Your password" 
                value={password} 
                onChange={(e) => setPassword(e.target.value)}
                className="w-full p-2 text-base border border-gray-300 rounded-md focus:border-blue-500 focus:ring focus:ring-blue-200"
              />
            </div>
          </form>
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button 
            variant="outline" 
            onClick={() => router.push('/')}
            className="text-sm px-4 py-2"
          >
            Back
          </Button>
          <Button 
            onClick={handleSubmit}
            className="text-sm px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white"
          >
            Sign Up
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}


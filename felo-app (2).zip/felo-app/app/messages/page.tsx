'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'

export default function Messages() {
  const [message, setMessage] = useState('')

  const handleSendMessage = () => {
    console.log('Sending message:', message)
    setMessage('')
  }

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-blue-600">Messages</h1>
      <div className="grid grid-cols-3 gap-6">
        <Card className="col-span-1">
          <CardHeader>
            <CardTitle>Contacts</CardTitle>
            <CardDescription>Your recent conversations</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {['John Doe', 'Jane Smith', 'Alice Johnson'].map((name) => (
                <div key={name} className="flex items-center space-x-4">
                  <Avatar>
                    <AvatarImage src={`https://api.dicebear.com/6.x/initials/svg?seed=${name}`} />
                    <AvatarFallback>{name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="text-sm font-medium leading-none">{name}</p>
                    <p className="text-sm text-muted-foreground">Last message preview...</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
        <Card className="col-span-2">
          <CardHeader>
            <CardTitle>Conversation</CardTitle>
            <CardDescription>Your messages with John Doe</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-start space-x-4">
                <Avatar>
                  <AvatarImage src="https://api.dicebear.com/6.x/initials/svg?seed=JD" />
                  <AvatarFallback>JD</AvatarFallback>
                </Avatar>
                <div className="space-y-2">
                  <p className="text-sm font-medium leading-none">John Doe</p>
                  <p className="text-sm">Hello! How can I help you today?</p>
                </div>
              </div>
              <div className="flex items-start space-x-4 justify-end">
                <div className="space-y-2">
                  <p className="text-sm font-medium leading-none">You</p>
                  <p className="text-sm">Hi John, I wanted to ask about the upcoming parent-teacher meeting.</p>
                </div>
                <Avatar>
                  <AvatarImage src="https://api.dicebear.com/6.x/initials/svg?seed=You" />
                  <AvatarFallback>You</AvatarFallback>
                </Avatar>
              </div>
            </div>
            <div className="mt-4 space-y-4">
              <Textarea
                placeholder="Type your message here"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
              />
              <Button onClick={handleSendMessage}>Send Message</Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}


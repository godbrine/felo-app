import Link from 'next/link'
import { Button } from '@/components/ui/button'
import Logo from '@/components/Logo'

export default function Home() {
  return (
    <div className="flex flex-col items-center justify-center min-h-[calc(100vh-64px)]">
      <div className="flex items-center mb-8">
        <Logo className="mr-4" />
        <h1 className="text-4xl font-bold text-blue-600">Welcome to Felo</h1>
      </div>
      <p className="text-xl text-gray-700 mb-8 text-center max-w-2xl">
        Felo connects parents and teachers to improve student outcomes and ensure timely sharing of information. Join our community for seamless communication and better education.
      </p>
      <div className="space-x-4 mb-8">
        <Button asChild size="lg">
          <Link href="/signup">Sign Up</Link>
        </Button>
        <Button asChild variant="outline" size="lg">
          <Link href="/login">Login</Link>
        </Button>
      </div>
      <p className="text-sm text-gray-500">Made by Saksham</p>
    </div>
  )
}


'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Calendar } from '@/components/ui/calendar'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import AIInsights from '@/components/AIInsights'
import ClassroomLiveUpdates from '@/components/ClassroomLiveUpdates'
import GamifiedProgress from '@/components/GamifiedProgress'
import CustomizableDashboard from '@/components/CustomizableDashboard'

export default function Dashboard() {
  const [date, setDate] = useState<Date | undefined>(new Date())

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-blue-800">Felo Dashboard</h1>
      <Tabs defaultValue="overview">
        <TabsList className="bg-blue-100">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="customize">Customize</TabsTrigger>
          <TabsTrigger value="ai-insights">AI Insights</TabsTrigger>
          <TabsTrigger value="live-updates">Live Updates</TabsTrigger>
          <TabsTrigger value="progress">Progress</TabsTrigger>
          <TabsTrigger value="attendance">Attendance</TabsTrigger>
          <TabsTrigger value="grades">Grades</TabsTrigger>
          <TabsTrigger value="homework">Homework</TabsTrigger>
          <TabsTrigger value="calendar">Calendar</TabsTrigger>
        </TabsList>
        <TabsContent value="overview">
          <CustomizableDashboard />
        </TabsContent>
        <TabsContent value="customize">
          <Card>
            <CardHeader>
              <CardTitle>Customize Your Dashboard</CardTitle>
              <CardDescription>Select the widgets you want to see on your overview page</CardDescription>
            </CardHeader>
            <CardContent>
              {/* Add checkboxes or toggle switches for each available widget */}
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="ai-insights">
          <AIInsights />
        </TabsContent>
        <TabsContent value="live-updates">
          <ClassroomLiveUpdates />
        </TabsContent>
        <TabsContent value="progress">
          <GamifiedProgress />
        </TabsContent>
        <TabsContent value="attendance">
          <Card>
            <CardHeader>
              <CardTitle>Attendance Record</CardTitle>
              <CardDescription>View and manage attendance</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Date</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Notes</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  <TableRow>
                    <TableCell>2023-05-01</TableCell>
                    <TableCell><Badge>Present</Badge></TableCell>
                    <TableCell>-</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell>2023-05-02</TableCell>
                    <TableCell><Badge variant="destructive">Absent</Badge></TableCell>
                    <TableCell>Doctor's appointment</TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="grades">
          <Card>
            <CardHeader>
              <CardTitle>Grade Book</CardTitle>
              <CardDescription>View current grades and academic progress</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Subject</TableHead>
                    <TableHead>Current Grade</TableHead>
                    <TableHead>Progress</TableHead>
                    <TableHead>Last Updated</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  <TableRow>
                    <TableCell>Mathematics</TableCell>
                    <TableCell>A</TableCell>
                    <TableCell><Progress value={90} className="w-[60%]" /></TableCell>
                    <TableCell>2023-05-01</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell>Science</TableCell>
                    <TableCell>B+</TableCell>
                    <TableCell><Progress value={85} className="w-[60%]" /></TableCell>
                    <TableCell>2023-05-02</TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="homework">
          <Card>
            <CardHeader>
              <CardTitle>Homework Assignments</CardTitle>
              <CardDescription>View and manage homework tasks</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Subject</TableHead>
                    <TableHead>Assignment</TableHead>
                    <TableHead>Due Date</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  <TableRow>
                    <TableCell>Mathematics</TableCell>
                    <TableCell>Chapter 5 Problems</TableCell>
                    <TableCell>2023-05-10</TableCell>
                    <TableCell><Badge variant="outline">Pending</Badge></TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell>Science</TableCell>
                    <TableCell>Lab Report</TableCell>
                    <TableCell>2023-05-15</TableCell>
                    <TableCell><Badge variant="success">Completed</Badge></TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="calendar">
          <Card>
            <CardHeader>
              <CardTitle>School Calendar</CardTitle>
              <CardDescription>View upcoming events and important dates</CardDescription>
            </CardHeader>
            <CardContent>
              <Calendar
                mode="single"
                selected={date}
                onSelect={setDate}
                className="rounded-md border"
              />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}


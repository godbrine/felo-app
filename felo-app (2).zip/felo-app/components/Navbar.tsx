'use client'

import Link from 'next/link'
import { usePathname, useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'
import Logo from '@/components/Logo'

const Navbar = () => {
  const pathname = usePathname()
  const router = useRouter()

  const isActive = (path: string) => pathname === path

  const handleLogout = () => {
    localStorage.removeItem('authToken')
    router.push('/login')
  }

  return (
    <nav className="bg-white shadow-md">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center py-4">
          <Link href="/" className="flex items-center space-x-2">
            <Logo />
            <span className="text-2xl font-bold text-blue-600">Felo</span>
          </Link>
          <div className="space-x-4">
            <Button asChild variant={isActive('/') ? 'default' : 'ghost'}>
              <Link href="/">Home</Link>
            </Button>
            <Button asChild variant={isActive('/dashboard') ? 'default' : 'ghost'}>
              <Link href="/dashboard">Dashboard</Link>
            </Button>
            <Button asChild variant={isActive('/messages') ? 'default' : 'ghost'}>
              <Link href="/messages">Messages</Link>
            </Button>
            <Button asChild variant={isActive('/signup') ? 'default' : 'ghost'}>
              <Link href="/signup">Sign Up</Link>
            </Button>
            <Button asChild variant="outline" onClick={handleLogout}>
              Logout
            </Button>
          </div>
        </div>
      </div>
    </nav>
  )
}

export default Navbar


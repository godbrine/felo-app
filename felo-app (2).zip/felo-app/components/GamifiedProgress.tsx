import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Progress } from '@/components/ui/progress'
import { Badge } from '@/components/ui/badge'

export default function GamifiedProgress() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Gamified Progress Tracking</CardTitle>
        <CardDescription>Track achievements and compete on leaderboards</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div>
            <h3 className="text-lg font-semibold">Current Level: Scholar</h3>
            <Progress value={75} className="mt-2" />
            <p className="text-sm text-muted-foreground mt-1">75/100 XP to next level</p>
          </div>
          <div>
            <h3 className="text-lg font-semibold">Recent Achievements</h3>
            <div className="flex flex-wrap gap-2 mt-2">
              <Badge variant="secondary">Perfect Attendance</Badge>
              <Badge variant="secondary">Math Whiz</Badge>
              <Badge variant="secondary">Science Fair Winner</Badge>
            </div>
          </div>
          <div>
            <h3 className="text-lg font-semibold">Leaderboard Position</h3>
            <p className="text-2xl font-bold mt-2">#3 in Grade</p>
            <p className="text-sm text-muted-foreground">Top 5% of all students</p>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}


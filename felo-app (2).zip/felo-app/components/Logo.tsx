import { FC } from 'react'

const Logo: FC<{ className?: string }> = ({ className = "" }) => {
  return (
    <svg className={`w-10 h-10 ${className}`} viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
      <rect width="40" height="40" rx="8" fill="#4F46E5" />
      <path d="M10 10C10 8.89543 10.8954 8 12 8H28C29.1046 8 30 8.89543 30 10V22C30 27.5228 25.5228 32 20 32C14.4772 32 10 27.5228 10 22V10Z" fill="white" />
      <path d="M15 14C15 12.8954 15.8954 12 17 12H23C24.1046 12 25 12.8954 25 14V22C25 24.7614 22.7614 27 20 27C17.2386 27 15 24.7614 15 22V14Z" fill="#4F46E5" />
    </svg>
  )
}

export default Logo


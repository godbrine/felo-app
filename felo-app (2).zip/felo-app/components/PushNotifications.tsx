'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Switch } from '@/components/ui/switch'
import { Label } from '@/components/ui/label'
import { toast } from '@/components/ui/use-toast'

export default function PushNotifications() {
  const [notificationsEnabled, setNotificationsEnabled] = useState(false)
  const [academicUpdates, setAcademicUpdates] = useState(true)
  const [behaviorUpdates, setBehaviorUpdates] = useState(true)
  const [eventReminders, setEventReminders] = useState(true)

  useEffect(() => {
    // Check if notifications are already enabled
    if ('Notification' in window) {
      setNotificationsEnabled(Notification.permission === 'granted')
    }
  }, [])

  const enableNotifications = async () => {
    if ('Notification' in window) {
      const permission = await Notification.requestPermission()
      if (permission === 'granted') {
        setNotificationsEnabled(true)
        toast({
          title: 'Notifications Enabled',
          description: 'You will now receive push notifications from Felo.',
        })
      }
    }
  }

  const sendTestNotification = () => {
    if ('Notification' in window && Notification.permission === 'granted') {
      new Notification('Test Notification', {
        body: 'This is a test notification from Felo.',
        icon: '/felo-icon.png',
      })
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Push Notifications</CardTitle>
        <CardDescription>Customize your notification preferences</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between">
          <Label htmlFor="notifications">Enable Notifications</Label>
          <Switch
            id="notifications"
            checked={notificationsEnabled}
            onCheckedChange={(checked) => {
              if (checked) {
                enableNotifications()
              } else {
                setNotificationsEnabled(false)
              }
            }}
          />
        </div>
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <Label htmlFor="academic">Academic Updates</Label>
            <Switch
              id="academic"
              checked={academicUpdates}
              onCheckedChange={setAcademicUpdates}
              disabled={!notificationsEnabled}
            />
          </div>
          <div className="flex items-center justify-between">
            <Label htmlFor="behavior">Behavior Updates</Label>
            <Switch
              id="behavior"
              checked={behaviorUpdates}
              onCheckedChange={setBehaviorUpdates}
              disabled={!notificationsEnabled}
            />
          </div>
          <div className="flex items-center justify-between">
            <Label htmlFor="events">Event Reminders</Label>
            <Switch
              id="events"
              checked={eventReminders}
              onCheckedChange={setEventReminders}
              disabled={!notificationsEnabled}
            />
          </div>
        </div>
        <Button onClick={sendTestNotification} disabled={!notificationsEnabled}>
          Send Test Notification
        </Button>
      </CardContent>
    </Card>
  )
}


import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'

export default function ClassroomLiveUpdates() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Classroom Live Updates</CardTitle>
        <CardDescription>Real-time notifications about in-class activities</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-semibold">Science Class</h3>
              <p className="text-sm text-muted-foreground">Group presentation on renewable energy</p>
            </div>
            <Badge>Live Now</Badge>
          </div>
          <div>
            <h3 className="text-lg font-semibold">Today's Highlights</h3>
            <ul className="list-disc list-inside space-y-1">
              <li>Answered 3 questions in Math class</li>
              <li>Completed a group exercise in English Literature</li>
              <li>Scheduled to present in Science class at 2 PM</li>
            </ul>
          </div>
          <div>
            <h3 className="text-lg font-semibold">Upcoming</h3>
            <p>Physics quiz in 30 minutes</p>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}


'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'

const widgets = [
  { id: 'attendance', title: 'Attendance', content: () => (
    <div>
      <div className="text-2xl font-bold">98%</div>
      <p className="text-xs text-muted-foreground">+2% from last month</p>
    </div>
  )},
  { id: 'grades', title: 'Average Grade', content: () => (
    <div>
      <div className="text-2xl font-bold">A-</div>
      <p className="text-xs text-muted-foreground">Improved from B+ last semester</p>
    </div>
  )},
  { id: 'homework', title: 'Homework Completion', content: () => (
    <div>
      <div className="text-2xl font-bold">95%</div>
      <p className="text-xs text-muted-foreground">+5% from last week</p>
    </div>
  )},
  { id: 'points', title: 'Participation Points', content: () => (
    <div>
      <div className="text-2xl font-bold">250</div>
      <p className="text-xs text-muted-foreground">+23 points this week</p>
    </div>
  )},
  { id: 'badges', title: 'Recent Badges', content: () => (
    <div className="flex flex-wrap gap-2">
      <Badge variant="secondary">Perfect Attendance</Badge>
      <Badge variant="secondary">Math Whiz</Badge>
      <Badge variant="secondary">Science Fair Winner</Badge>
    </div>
  )},
  { id: 'nextEvent', title: 'Next Event', content: () => (
    <div>
      <p className="font-semibold">Parent-Teacher Conference</p>
      <p className="text-sm text-muted-foreground">May 15, 2023 at 4:00 PM</p>
    </div>
  )},
]

export default function CustomizableDashboard() {
  const [activeWidgets, setActiveWidgets] = useState(widgets.map(w => w.id))

  const toggleWidget = (id: string) => {
    setActiveWidgets(prev => 
      prev.includes(id) ? prev.filter(w => w !== id) : [...prev, id]
    )
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle>Your Dashboard</CardTitle>
          <CardDescription>Customize your view by clicking on the widgets below</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            {widgets.map(widget => (
              <Card 
                key={widget.id} 
                className={`cursor-pointer transition-all ${activeWidgets.includes(widget.id) ? 'ring-2 ring-blue-600 bg-blue-50' : 'bg-white'}`}
                onClick={() => toggleWidget(widget.id)}
              >
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium text-blue-800">{widget.title}</CardTitle>
                </CardHeader>
                <CardContent className="text-gray-700">
                  {widget.content()}
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>
      <Card>
        <CardHeader>
          <CardTitle>Gamification Progress</CardTitle>
          <CardDescription>Your journey to becoming a star student</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <h3 className="text-lg font-semibold">Current Level: Scholar</h3>
              <Progress value={75} className="mt-2" />
              <p className="text-sm text-muted-foreground mt-1">75/100 XP to next level</p>
            </div>
            <div>
              <h3 className="text-lg font-semibold">Recent Achievements</h3>
              <div className="flex flex-wrap gap-2 mt-2">
                <Badge variant="secondary">Perfect Attendance</Badge>
                <Badge variant="secondary">Math Whiz</Badge>
                <Badge variant="secondary">Science Fair Winner</Badge>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

